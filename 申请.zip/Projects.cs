﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using OfficeOpenXml;
using System.IO;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 申请
{


    public partial class Projects : Form
    {
        Form1 form1 = new Form1();
        public List<ProjectData> excelData;
        public SmsBaseClass fSmsBaseClass;
        private string excelFilePath;
        public Projects()
        {
            
            InitializeComponent();
           
            
            excelData = new List<ProjectData>();
            //ReadExcelData(excelFilePath);
           
        }

        public class ProjectData
        {
            public string Type { get; set; }
            public string CreateTime { get; set; }
            public string ProjectName { get; set; }
            public string ProjectNumber { get; set; }
            public string JieGou { get; set; }
            public string DianQi { get; set; }
            public string RuanJian { get; set; }
            public string CeShi { get; set; }
        }
        #region  读取excel表格数据
        private void ReadExcelData(string filePath)
        {
            // 清空现有数据
            excelData.Clear();

            FileInfo fileInfo = new FileInfo(filePath);
            using (var package = new ExcelPackage(fileInfo))
            {

                if (package.Workbook.Worksheets.Count == 0)
                {
                    throw new Exception("工作表不存在。");
                }

                ExcelWorksheet worksheet = null;
                try
                {
                    worksheet = package.Workbook.Worksheets[0];
                }
                catch (IndexOutOfRangeException)
                {
                    throw new Exception("尝试访问的工作表索引超出范围。");
                }

                if (worksheet == null)
                {
                    throw new Exception("工作表为空。");
                }


                for (int row = 2; row <= worksheet.Dimension.End.Row; row += 4)
                    {
                        if (worksheet.Dimension.End.Column < 10)
                        {
                            continue; // 如果没有，跳过当前的四行
                        }

                        if (string.IsNullOrWhiteSpace(worksheet.Cells[row, 4].Text)) break;

                        var projectData = new ProjectData
                        {
                            //读取excel表中的Types[AI或者B]
                            Type = worksheet.Cells[row, 2].Text,

                            //读取excel表中的立项的时间
                            CreateTime = worksheet.Cells[row, 1].Text,

                            //读取excel表中电气的设计人员
                            DianQi = worksheet.Cells[row, 10].Text,

                            //读取excel表中的测试设计人员
                            CeShi = worksheet.Cells[row + 1, 10].Text,

                            //读取excel表中的结构设计人员
                            JieGou = worksheet.Cells[row + 2, 10].Text,

                            //读取excel表中的软件设计人员
                            RuanJian = worksheet.Cells[row + 3, 10].Text,

                            //读取excel表中的ProjectName
                            ProjectName = worksheet.Cells[row, 5].Text,

                            //读取excel表中的ProjectNumber [立项时的编号]
                            ProjectNumber = worksheet.Cells[row, 4].Text
                        };  

                        excelData.Add(projectData);
                    }


               } 
        }
        
        #endregion

        //public class ExcelReader
        //{

        //    public List<string> GetFilteredProjects(string filePath, string type, string machineType)
        //    {
        //        var items = new List<string>();
        //        FileInfo fileInfo = new FileInfo(filePath);
        //        using (var package = new ExcelPackage(fileInfo))
        //        {
        //            var worksheet = package.Workbook.Worksheets[0]; // 假设数据在第一个工作表

        //            for (int row = 2; row <= worksheet.Dimension.End.Row; row++) // 假设从第二行开始读取
        //            {
        //                if (string.IsNullOrWhiteSpace(worksheet.Cells[row, 5].Text))
        //                {
        //                    break; // 如果 E 列为空，则停止循环,即项目编号为空时
        //                }

        //                string typeValue = worksheet.Cells[row, 3].Text; // C列
        //                string machineTypeValue = worksheet.Cells[row, 8].Text; // H列
        //                if (typeValue == type && machineTypeValue == machineType)
        //                {
        //                    string projectName = worksheet.Cells[row, 7].Text; // G列
        //                    if (!string.IsNullOrEmpty(projectName))
        //                    {
        //                        items.Add(projectName);
        //                    }
        //                }
        //            }

        //        }
        //        return items;

        //    }

        //}

        //用来筛选是AI还是B社
        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateComboBox3();
        }


        //用来筛选日期
        private void ComboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateComboBox3();
        }

        //用来筛选电气的设计人员
        private void DianQiBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateComboBox3();
        }

        //用来筛选结构的设计人员
        private void JieGouBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateComboBox3();
        }

        //用来筛选软件的设计人员
        private void RuanJianBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateComboBox3();
        }

        //用来筛选测试的设计人员
        private void CeShiBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateComboBox3();
        }


        private void comboBox3_DropDown(object sender, EventArgs e)
        {
            // 更新 comboBox3 的内容
            UpdateComboBox3();
        }



        private void UpdateComboBox3()
        {
            string type = comboBox1.SelectedItem?.ToString(); // 从 ComboBox1 获取选定的类型
            string createtime = comboBox2.SelectedItem?.ToString(); // 从 ComboBox2 获取选定的机器类型
            string dianqi = DianQiBox.SelectedItem?.ToString();//获取电气设计人员
            string jiegou = JieGouBox.SelectedItem?.ToString();// 获取结构设计人员
            string ruanjian = RuanJianBox.SelectedItem?.ToString(); //获取软件设计人员
            string ceshi = CeShiBox.SelectedItem?.ToString();   //获取测试设计人员
            int monthNumber = 0;
            if (!string.IsNullOrEmpty(createtime))
            {
                monthNumber = int.Parse(createtime.Replace("月", ""));
            }
            var filteredProjects = excelData
           .Where(p => (string.IsNullOrEmpty(type) || p.Type == type) &&
                       (monthNumber == 0 || (DateTime.TryParse(p.CreateTime, out DateTime createTime) && createTime.Month == monthNumber)) &&
                       (string.IsNullOrEmpty(dianqi) || p.DianQi == dianqi) &&
                       (string.IsNullOrEmpty(ceshi) || p.CeShi == ceshi) &&
                       (string.IsNullOrEmpty(jiegou) || p.JieGou == jiegou) &&
                       (string.IsNullOrEmpty(ruanjian) || p.RuanJian == ruanjian))
                .Select(p => p.ProjectName)
                .Distinct()
                .ToList();

            comboBox3.Items.Clear();
            comboBox3.Items.AddRange(filteredProjects.ToArray());
        
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            Form1 form1 = new Form1();
           
            form1.SetProjectNumber(selectedProjectNumber);
            form1.Show();
            this.Hide();
        }

        private void Xuanze_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Excel Files|*.xlsx;*.xls",
                Title = "Select an Excel File"
            };

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                excelFilePath = openFileDialog.FileName;
                string fileName = Path.GetFileName(excelFilePath); // 获取文件名
                textBox1.Text = fileName;
                // 在这里重新调用 ReadExcelData 方法，使用新的文件路径
                ReadExcelData(excelFilePath);
            }
        }

        public void LoadData(string filePath)
        {
            excelFilePath = filePath;
            ReadExcelData(excelFilePath);
        }


        //返回按钮
        private void button2_Click(object sender, EventArgs e)
        {
            if (fSmsBaseClass != null && fSmsBaseClass.IsOpen)
            {
                fSmsBaseClass.ClosePort(); // 关闭串口
            }
            form1.Show();
            this.Hide();
        }
        private string selectedProjectNumber;
        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            //每次点击combobox3的下拉按钮都会执行Updatacombobox3
           
            string selectedProjectName = comboBox3.SelectedItem?.ToString();
            selectedProjectNumber = excelData.FirstOrDefault(p => p.ProjectName == selectedProjectName)?.ProjectNumber;
        }

        private void Projects_FormClosing(object sender, FormClosingEventArgs e)
        {
            //Application.Exit();
            Environment.Exit(0);

        }

        private void Projects_Load(object sender, EventArgs e)
        {

        }

       
    }
    
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 申请
{
    public partial class DengLu : Form
    {
        //定义可以访问人员的工号
        public string[] EmployeeID = new string[] { "622003", "621003" };
        public string enteredEmployeeID = "";
        private System.Windows.Forms.Timer readCardTimer;
        private DateTime lastClickTime;
        private DateTime startTime;
        public DengLu()
        {
            InitializeComponent();
            readCardTimer = new Timer();
            readCardTimer.Interval = 1000; // 每秒尝试读取一次
            readCardTimer.Tick += ReadCardTimer_Tick;
            startTime = DateTime.Now; // 设置startTime为当前时间
            readCardTimer.Start(); // 启动定时器

        }

        #region 刷卡机的程序
        private void ReadCardTimer_Tick(object sender, EventArgs e)
        {
            if ((DateTime.Now - startTime).TotalSeconds >= 30)
            {
                // 停止 Timer
                readCardTimer.Stop();
                
                return;
            }

            byte mode = 0x00;
            byte blk_add = 0x01;
            byte num_blk = 1;
            byte[] snr = { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF };



            byte[] buffer = new byte[16 * num_blk];

            int nRet = Reader.MF_Read(mode, blk_add, num_blk, snr, buffer);

            Console.WriteLine(nRet);

            if (nRet == 0)
            {
                string first3Bytes = BitConverter.ToString(buffer, 0, 3).Replace("-", "");
                Console.WriteLine(first3Bytes);
                this.Invoke(new Action(() =>
                {
                    textBox1.Text = first3Bytes;
                    enteredEmployeeID = textBox1.Text;
                }));

            }


        }
        #endregion
        


        private void button1_Click(object sender, EventArgs e)
        {
            if (EmployeeID.Contains(enteredEmployeeID))
            {

                Form1.EmployeeID = enteredEmployeeID;
                Form1 form1 = new Form1();

                // 显示Form1窗体
                form1.Show();

             

                // 隐藏当前窗体 (DengLu)
                this.Hide();

            }

            else
            {

                MessageBox.Show("请刷正确的卡,打开超过30s刷卡器休眠，重开软件");

            }

        }

        private void DengLu_Load(object sender, EventArgs e)
        {

        }
    }
}
